(function() {
    'use strict';


    var url = new URL(window.location);
    var guko = url.searchParams.get("guko");
    var n = url.searchParams.get("n");
    var nx = url.searchParams.get("nx");
    var nn = Number(n)+1;

    if(guko == "joss"){
        setInterval(function(){

            document.getElementsByTagName('title')[0].innerHTML = "Auto WhatsApp"
            document.getElementsByTagName('header')[1].children[2].style.display = "none"

        },500)

        var auto = setInterval(function(){
            document.getElementById('side').parentElement.style.display = 'none';
            //document.getElementById('main').parentElement.style = 'margin-left:20%';
            document.getElementById('main').style.width = '650px';
            if(document.querySelector('span[data-icon="send"]')){
                document.querySelector('span[data-icon="send"]').click();

                closeWA();
                clearInterval(auto)
            }

        },2000)

        setInterval(function(){
            var x = document.getElementsByTagName('div');
            for (var i = 0; i < x.length; i++) {
                if((x[i].innerHTML) == "OK"){
                    x[i].click();
                    if(nn < nx){
                        window.location.href = "https://laksa19.github.io/autowa/run?n="+nn
                    }else{
                        window.location.href = "https://laksa19.github.io/autowa/run?done"
                    }
                }
            }
        },2000)

        function closeWA(){

            document.getElementsByTagName("header")[1].innerHTML += ('<div id="cd">Sending next message in 6</div>')
            var counter = 6

            var auto = setInterval(function(){

                counter--;

                document.getElementById('cd').innerHTML ="Sending next message in "+ counter;

                if (counter == 0) {

                    document.getElementById('cd').innerHTML = "Open Auto WhatsApp...";
                    if(nn < nx){
                        window.location.href = "https://laksa19.github.io/autowa/run?n="+nn
                    }else{
                        window.location.href = "https://laksa19.github.io/autowa/run?done"
                    }
                    clearInterval(auto);

                }

            }, 1000);

        }




    }
})();
